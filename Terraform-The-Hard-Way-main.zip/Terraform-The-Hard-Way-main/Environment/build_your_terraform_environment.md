## Build A Terraform Environment

To build your environment, take a look at my free Terraform video from my "Terraform For All" course which you can find [here](https://www.youtube.com/watch?v=PR3RnimYd2k&t=1s)